"""
TJR-style backtest: liquidity sweeps + MSS + FVG + SMT divergence.

A mechanical implementation of ICT/TJR concepts. Discretionary judgment is
replaced with hard rules — this may or may not match what a human trader
would do, but it's testable and honest.

Trading rules (long side; shorts are mirror):
  1. Higher-timeframe bias: 4h slow MA (100) must be rising.
  2. Session filter: only trade during London (07–10 UTC) or NY AM (12–15 UTC).
  3. Liquidity sweep: 5m bar wicks below the prior Asia-session low (00–06 UTC),
     then closes back above that low (failed breakdown).
  4. SMT divergence (optional): on the sweep bar, ETH must NOT have swept the
     corresponding level (ETH held while BTC "lied").
  5. MSS: within the next 12 bars (1 hour), a 5m bar closes above the most
     recent 5m swing high that formed since the sweep.
  6. Conviction: the MSS break bar's range must be >= 1.25x the avg range
     of the prior 20 bars.
  7. FVG entry: after MSS, wait for price to retrace into the bullish FVG
     created by the break (the gap between bar[t-1].high and bar[t+1].low).
     Enter long at the FVG midpoint.
  8. Stop: at the sweep low (where the wick bottomed), buffered by 0.1%.
  9. Take-profit: at N × R where R = entry - stop. We test 2R, 3R, 5R.

Shorts mirror this against Asia highs.

Run: python -m bot.tjr
"""
from __future__ import annotations
import time
from dataclasses import dataclass, field
from typing import Optional

import ccxt
import pandas as pd

from config.settings import CONFIG


# ---------- Data fetching ----------

def fetch_5m(symbol: str, days: int = 730) -> pd.DataFrame:
    """Paginate Binance for `days` of 5m candles for `symbol`."""
    ex = ccxt.binance({"enableRateLimit": True})
    tf_ms = 5 * 60 * 1000
    limit = 1000
    end_ms = int(time.time() * 1000)
    start_ms = end_ms - days * 86_400_000

    rows: list = []
    since = start_ms
    print(f"Fetching ~{days} days of 5m candles for {symbol}…")
    calls = 0
    while since < end_ms:
        batch = ex.fetch_ohlcv(symbol, timeframe="5m", since=since, limit=limit)
        if not batch:
            break
        rows.extend(batch)
        last_ts = batch[-1][0]
        if last_ts <= since:
            break
        since = last_ts + tf_ms
        calls += 1
        if calls % 20 == 0:
            print(f"  {symbol}: {len(rows)} bars so far")

    df = pd.DataFrame(rows, columns=["ts", "open", "high", "low", "close", "volume"])
    df = df.drop_duplicates(subset="ts").sort_values("ts").reset_index(drop=True)
    df["ts"] = pd.to_datetime(df["ts"], unit="ms", utc=True)
    return df


# ---------- Session and liquidity level logic ----------

def tag_sessions(df: pd.DataFrame) -> pd.DataFrame:
    """Add columns: session (str), date (UTC date), tradeable (bool)."""
    df = df.copy()
    hour = df["ts"].dt.hour
    df["date"] = df["ts"].dt.date
    # Asia: 00-06 UTC (captures Tokyo liquidity pool)
    # London: 07-10 UTC (manipulation window)
    # NY AM: 12-15 UTC (expansion window)
    def session(h: int) -> str:
        if 0 <= h < 7:
            return "asia"
        if 7 <= h < 12:
            return "london"
        if 12 <= h < 16:
            return "ny_am"
        return "off"
    df["session"] = hour.map(session)
    df["tradeable"] = df["session"].isin(("london", "ny_am"))
    return df


def asia_levels(df: pd.DataFrame) -> dict:
    """For each UTC date, return (asia_high, asia_low) from 00-06 UTC bars."""
    asia = df[df["session"] == "asia"]
    grouped = asia.groupby("date").agg(asia_high=("high", "max"),
                                        asia_low=("low", "min"))
    return grouped.to_dict(orient="index")


# ---------- Higher-timeframe bias ----------

def add_4h_bias(df: pd.DataFrame) -> pd.DataFrame:
    """Resample 5m → 4h, compute a 100-period MA, forward-fill its slope onto 5m."""
    df = df.copy()
    df_4h = (df.set_index("ts")["close"]
               .resample("4h").last()
               .to_frame("close_4h"))
    df_4h["ma_4h"] = df_4h["close_4h"].rolling(100, min_periods=100).mean()
    df_4h["ma_4h_prev"] = df_4h["ma_4h"].shift(6)  # 24h ago
    df_4h["bias_long"] = df_4h["ma_4h"] > df_4h["ma_4h_prev"]
    df_4h["bias_short"] = df_4h["ma_4h"] < df_4h["ma_4h_prev"]
    # Align back to 5m
    df = df.set_index("ts")
    df[["bias_long", "bias_short"]] = df_4h[["bias_long", "bias_short"]].reindex(
        df.index, method="ffill")
    df[["bias_long", "bias_short"]] = df[["bias_long", "bias_short"]].fillna(False)
    return df.reset_index()


# ---------- Trade dataclass ----------

@dataclass
class Trade:
    entry_ts: pd.Timestamp
    entry_price: float
    exit_ts: Optional[pd.Timestamp]
    exit_price: Optional[float]
    side: str         # "long" or "short"
    reason: str
    r_multiple: float = 0.0  # actual R achieved


# ---------- Core helpers ----------

def recent_swing_high(df: pd.DataFrame, end_idx: int, lookback: int = 12) -> Optional[float]:
    """Highest high in the lookback window ending at end_idx (inclusive)."""
    start = max(0, end_idx - lookback + 1)
    window = df.iloc[start:end_idx + 1]
    if len(window) == 0:
        return None
    return float(window["high"].max())


def recent_swing_low(df: pd.DataFrame, end_idx: int, lookback: int = 12) -> Optional[float]:
    start = max(0, end_idx - lookback + 1)
    window = df.iloc[start:end_idx + 1]
    if len(window) == 0:
        return None
    return float(window["low"].min())


def avg_range(df: pd.DataFrame, end_idx: int, n: int = 20) -> float:
    start = max(0, end_idx - n)
    window = df.iloc[start:end_idx]
    if len(window) == 0:
        return 0.0
    ranges = window["high"] - window["low"]
    return float(ranges.mean())


def eth_swept_level(eth_df: pd.DataFrame, ts: pd.Timestamp, eth_level: float,
                    direction: str, window_bars: int = 3) -> bool:
    """Did ETH also sweep its corresponding level around the same time?
    direction='low' means we check if eth.low went below eth_level.
    direction='high' means we check if eth.high went above eth_level."""
    mask = (eth_df["ts"] >= ts - pd.Timedelta(minutes=15)) & \
           (eth_df["ts"] <= ts + pd.Timedelta(minutes=5))
    window = eth_df[mask]
    if len(window) == 0:
        return False  # no data → assume not swept (conservative for SMT filter)
    if direction == "low":
        return bool(window["low"].min() < eth_level)
    return bool(window["high"].max() > eth_level)


# ---------- Strategy ----------

@dataclass
class TjrConfig:
    take_r: float = 3.0          # take-profit at this many R
    stop_buffer: float = 0.001   # 0.1% beyond the sweep extreme
    mss_lookback: int = 12       # bars after sweep to find MSS (12 × 5m = 1h)
    conviction_mult: float = 1.25         # for longs
    conviction_mult_short: float = 2.0    # shorts need stricter conviction (reversal signal)
    conviction_n: int = 20
    require_smt: bool = False    # SMT divergence filter
    allow_shorts: bool = True
    require_4h_bias_short: bool = True  # require 4h MA falling for shorts
    fee: float = 0.0052          # round-trip taker


def run_tjr(btc: pd.DataFrame, eth: Optional[pd.DataFrame], cfg: TjrConfig) -> list[Trade]:
    """Core backtest loop. btc and eth are both 5m with sessions + bias already tagged."""
    trades: list[Trade] = []
    asia = asia_levels(btc)

    # Pre-index eth on timestamp for faster lookups if provided
    eth_df = eth if eth is not None else None

    # State machine per setup: sweep detected → wait for MSS → wait for FVG retrace → entry
    pending_long: Optional[dict] = None
    pending_short: Optional[dict] = None

    for i in range(1, len(btc) - 2):
        bar = btc.iloc[i]
        ts = bar["ts"]
        date = bar["date"]

        # Invalidate stale pendings (>1 hour old)
        for pending in [pending_long, pending_short]:
            if pending and (ts - pending["sweep_ts"]) > pd.Timedelta(hours=1):
                pending.clear()
        if pending_long is not None and not pending_long:
            pending_long = None
        if pending_short is not None and not pending_short:
            pending_short = None

        # Get Asia levels for this UTC date
        lvls = asia.get(date)
        if lvls is None:
            continue

        asia_low = lvls["asia_low"]
        asia_high = lvls["asia_high"]

        # --- Sweep detection: can happen any time in London/NY sessions ---
        if bar["tradeable"]:
            # Long setup: swept Asia low then closed back above
            if (bar["low"] < asia_low
                and bar["close"] > asia_low
                and bar["bias_long"]
                and pending_long is None):
                # SMT filter: ETH must NOT have also swept its level
                if cfg.require_smt and eth_df is not None:
                    eth_lvls = asia_levels(eth_df).get(date)
                    if eth_lvls and eth_swept_level(eth_df, ts, eth_lvls["asia_low"], "low"):
                        pass  # both swept → no SMT divergence → skip
                    else:
                        pending_long = _new_pending("long", i, bar, asia_low)
                else:
                    pending_long = _new_pending("long", i, bar, asia_low)

            # Short setup: swept Asia high then closed back below
            if (cfg.allow_shorts and bar["high"] > asia_high
                and bar["close"] < asia_high
                and bar["bias_short"]
                and pending_short is None):
                if cfg.require_smt and eth_df is not None:
                    eth_lvls = asia_levels(eth_df).get(date)
                    if eth_lvls and eth_swept_level(eth_df, ts, eth_lvls["asia_high"], "high"):
                        pass
                    else:
                        pending_short = _new_pending("short", i, bar, asia_high)
                else:
                    pending_short = _new_pending("short", i, bar, asia_high)

        # --- MSS + FVG handling for pending setups ---
        if pending_long is not None:
            result = _process_pending(btc, i, pending_long, cfg, "long")
            if result == "entered":
                trades.append(pending_long["trade"])
                pending_long = None
            elif result == "invalidated":
                pending_long = None

        if pending_short is not None:
            result = _process_pending(btc, i, pending_short, cfg, "short")
            if result == "entered":
                trades.append(pending_short["trade"])
                pending_short = None
            elif result == "invalidated":
                pending_short = None

    return trades


def _new_pending(side: str, i: int, bar: pd.Series, swept_level: float) -> dict:
    return {
        "side": side,
        "sweep_idx": i,
        "sweep_ts": bar["ts"],
        "sweep_extreme": bar["low"] if side == "long" else bar["high"],
        "swept_level": swept_level,
        "mss_found": False,
        "mss_idx": None,
        "mss_high": None,
        "mss_low": None,
    }


def _process_pending(df: pd.DataFrame, i: int, p: dict, cfg: TjrConfig, side: str) -> str:
    """Returns 'entered', 'invalidated', or 'pending'."""
    bars_since_sweep = i - p["sweep_idx"]

    # Hard invalidation: price took out the sweep extreme before we entered
    if side == "long" and df["low"].iloc[i] < p["sweep_extreme"]:
        return "invalidated"
    if side == "short" and df["high"].iloc[i] > p["sweep_extreme"]:
        return "invalidated"

    # Phase 1: waiting for MSS
    if not p["mss_found"]:
        if bars_since_sweep > cfg.mss_lookback:
            return "invalidated"
        if bars_since_sweep < 2:
            return "pending"  # need some bars to form a swing
        # MSS long: current bar closes above the highest high seen since sweep
        # MSS short: current bar closes below the lowest low seen since sweep
        since_sweep = df.iloc[p["sweep_idx"] + 1:i]
        if len(since_sweep) < 2:
            return "pending"
        if side == "long":
            swing_high = float(since_sweep["high"].iloc[:-1].max())
            if df["close"].iloc[i] > swing_high:
                # Conviction check
                this_range = df["high"].iloc[i] - df["low"].iloc[i]
                avg = avg_range(df, i, cfg.conviction_n)
                if avg > 0 and this_range >= cfg.conviction_mult * avg:
                    p["mss_found"] = True
                    p["mss_idx"] = i
                    p["mss_high"] = float(df["high"].iloc[i])
                    p["mss_low"] = float(df["low"].iloc[i])
                    # FVG check — bullish FVG = bar[i-1].high < bar[i+1].low
                    # We need bar i+1 to know, so handle that next tick
                    return "pending"
        else:
            swing_low = float(since_sweep["low"].iloc[:-1].min())
            if df["close"].iloc[i] < swing_low:
                this_range = df["high"].iloc[i] - df["low"].iloc[i]
                avg = avg_range(df, i, cfg.conviction_n)
                # Shorts require stricter conviction — need drastic reversal signal
                required_mult = cfg.conviction_mult_short
                if avg > 0 and this_range >= required_mult * avg:
                    p["mss_found"] = True
                    p["mss_idx"] = i
                    p["mss_high"] = float(df["high"].iloc[i])
                    p["mss_low"] = float(df["low"].iloc[i])
                    return "pending"
        return "pending"

    # Phase 2: MSS done, looking for FVG retrace entry
    mss_i = p["mss_idx"]
    if i - mss_i > 10:  # FVG must fill within 10 bars or bail
        return "invalidated"
    if i - mss_i < 2:   # need bar at mss_i+1 to exist
        return "pending"

    bar_prev = df.iloc[mss_i - 1]
    bar_mss = df.iloc[mss_i]
    bar_next = df.iloc[mss_i + 1]
    if side == "long":
        fvg_low = float(bar_prev["high"])
        fvg_high = float(bar_next["low"])
        if fvg_high <= fvg_low:
            return "invalidated"  # no actual gap
        fvg_mid = (fvg_high + fvg_low) / 2
        # Did this bar retrace into the FVG?
        if df["low"].iloc[i] <= fvg_mid <= df["high"].iloc[i]:
            entry = fvg_mid
            stop = p["sweep_extreme"] * (1 - cfg.stop_buffer)
            r = entry - stop
            if r <= 0:
                return "invalidated"
            take = entry + cfg.take_r * r
            # Simulate forward to exit
            exit_ts, exit_price, reason = _simulate_exit(df, i + 1, entry, stop, take, "long")
            # R multiple
            r_mult = ((exit_price - entry) / r) if exit_price else 0.0
            # Apply fee
            r_after_fee = r_mult - (cfg.fee / (r / entry)) if r > 0 else r_mult
            p["trade"] = Trade(
                entry_ts=df["ts"].iloc[i],
                entry_price=entry,
                exit_ts=exit_ts,
                exit_price=exit_price,
                side="long",
                reason=reason,
                r_multiple=r_mult,
            )
            return "entered"
    else:
        fvg_high = float(bar_prev["low"])
        fvg_low = float(bar_next["high"])
        if fvg_high <= fvg_low:
            return "invalidated"
        fvg_mid = (fvg_high + fvg_low) / 2
        if df["low"].iloc[i] <= fvg_mid <= df["high"].iloc[i]:
            entry = fvg_mid
            stop = p["sweep_extreme"] * (1 + cfg.stop_buffer)
            r = stop - entry
            if r <= 0:
                return "invalidated"
            take = entry - cfg.take_r * r
            exit_ts, exit_price, reason = _simulate_exit(df, i + 1, entry, stop, take, "short")
            r_mult = ((entry - exit_price) / r) if exit_price else 0.0
            p["trade"] = Trade(
                entry_ts=df["ts"].iloc[i],
                entry_price=entry,
                exit_ts=exit_ts,
                exit_price=exit_price,
                side="short",
                reason=reason,
                r_multiple=r_mult,
            )
            return "entered"
    return "pending"


def _simulate_exit(df: pd.DataFrame, start_idx: int, entry: float, stop: float,
                   take: float, side: str, max_bars: int = 200):
    """Walk forward bar-by-bar, check stop/take. Returns (ts, price, reason)."""
    end = min(len(df), start_idx + max_bars)
    for j in range(start_idx, end):
        hi = df["high"].iloc[j]
        lo = df["low"].iloc[j]
        if side == "long":
            # Assume worst-case: stop checked before take within same bar
            if lo <= stop:
                return df["ts"].iloc[j], stop, "stop"
            if hi >= take:
                return df["ts"].iloc[j], take, "take"
        else:
            if hi >= stop:
                return df["ts"].iloc[j], stop, "stop"
            if lo <= take:
                return df["ts"].iloc[j], take, "take"
    # Time-out at last bar
    return df["ts"].iloc[end - 1], float(df["close"].iloc[end - 1]), "timeout"


# ---------- Reporting ----------

def summarize(label: str, trades: list[Trade], cfg: TjrConfig) -> None:
    if not trades:
        print(f"{label:<48} {'no trades':<55}")
        return
    rs = pd.Series([t.r_multiple for t in trades])
    wins = rs[rs > 0]
    # Convert R multiples to account-% returns assuming 1% risk per trade.
    # A 3R win = +3% of account; a -1R loss = -1% of account.
    risk_per_trade = 0.01
    pct_returns = rs * risk_per_trade
    # Fee model: round-trip taker fee applies to full notional (not just risk).
    # Assume position size = (risk_per_trade) / (stop_distance_pct).
    # For TJR, stop is typically ~0.5% away on 5m setups, so notional ≈ 2x account.
    # Approximate fee drag per trade: 0.52% * 2 = ~1% on account per trade.
    # This is a rough estimate — real fee impact depends on each trade's stop distance.
    est_fee_per_trade = cfg.fee * 2  # conservative
    pct_net = pct_returns - est_fee_per_trade
    cum_gross = (1 + pct_returns).prod() - 1
    cum_net = (1 + pct_net).prod() - 1
    win_rate = len(wins) / len(rs)
    avg_r = rs.mean()
    print(f"{label:<48} {len(trades):>5}  {win_rate:>6.1%}  "
          f"{avg_r:>+6.2f}R  {cum_gross:>+8.2%}  {cum_net:>+8.2%}")


def main() -> None:
    # Fetch once, use both ways: BTC and ETH
    btc = fetch_5m("BTC/USDT", days=730)
    if len(btc) == 0:
        print("No BTC data returned.")
        return
    print(f"BTC: {len(btc)} bars from {btc['ts'].iloc[0]} to {btc['ts'].iloc[-1]}")

    eth = fetch_5m("ETH/USDT", days=730)
    print(f"ETH: {len(eth)} bars")

    print("\nTagging sessions and computing 4h bias for BTC…")
    btc = tag_sessions(btc)
    btc = add_4h_bias(btc)

    print("Tagging sessions and computing 4h bias for ETH…")
    eth = tag_sessions(eth)
    eth = add_4h_bias(eth)

    # Buy-and-hold benchmarks
    bnh_btc = (btc["close"].iloc[-1] / btc["close"].iloc[0]) - 1
    bnh_eth = (eth["close"].iloc[-1] / eth["close"].iloc[0]) - 1

    print()
    print(f"{'Variant':<48} {'Trades':>5}  {'Win%':>6}  {'Avg R':>6}  {'Gross%':>8}  {'Net%':>8}")
    print("-" * 96)

    # --- BTC-based strategies (previous work, kept for reference) ---
    btc_variants = [
        ("BTC: 3R longs only, SMT (prev best)",
         TjrConfig(take_r=3.0, require_smt=True, allow_shorts=False)),
    ]
    for label, cfg in btc_variants:
        trades = run_tjr(btc, eth, cfg)
        summarize(label, trades, cfg)

    print("-" * 96)
    print("ETH/USDT variants (ETH primary, BTC as SMT reference):")
    print("-" * 96)

    # --- ETH-based strategies: ETH is primary, BTC is the SMT reference ---
    eth_variants = [
        ("ETH: 3R longs only, no SMT",
         TjrConfig(take_r=3.0, require_smt=False, allow_shorts=False)),
        ("ETH: 3R longs only, with SMT",
         TjrConfig(take_r=3.0, require_smt=True, allow_shorts=False)),
        ("ETH: 3R longs+shorts, strict shorts (2.0)",
         TjrConfig(take_r=3.0, require_smt=True, allow_shorts=True,
                   conviction_mult=1.25, conviction_mult_short=2.0)),
        ("ETH: 5R longs only, with SMT",
         TjrConfig(take_r=5.0, require_smt=True, allow_shorts=False)),
        ("ETH: 2R longs only, with SMT",
         TjrConfig(take_r=2.0, require_smt=True, allow_shorts=False)),
    ]
    for label, cfg in eth_variants:
        # ETH primary, BTC as SMT reference
        trades = run_tjr(eth, btc, cfg)
        summarize(label, trades, cfg)

    print("-" * 96)
    print(f"{'BUY-AND-HOLD BTC benchmark':<48} {'—':>5}  {'—':>6}  "
          f"{'—':>6}  {bnh_btc:>+8.2%}  {bnh_btc:>+8.2%}")
    print(f"{'BUY-AND-HOLD ETH benchmark':<48} {'—':>5}  {'—':>6}  "
          f"{'—':>6}  {bnh_eth:>+8.2%}  {bnh_eth:>+8.2%}")
    print()
    print("Account-% assumes 1% risk per trade. Fee drag estimated at 0.52% per round trip.")
    print("Avg R is average multiple of initial risk per trade (before fees).")


if __name__ == "__main__":
    main()
