"""
Main loop. Run with:  python -m bot.runner

This intentionally runs as a long-lived process rather than a cron job, because:
  - It needs to hold state (position, peak equity) between polls.
  - Exchange rate limits are easier to respect with a single process.

If you want cron-style scheduling, run this under systemd, supervisord, or a
container restart policy so it stays up.
"""
from __future__ import annotations
import logging
import logging.handlers
import signal
import sys
import time
from pathlib import Path

from bot.broker import Broker
from bot.strategy import MaRsiStrategy
from config.settings import CONFIG


def setup_logging() -> None:
    log_dir = Path(__file__).resolve().parent.parent / "logs"
    log_dir.mkdir(exist_ok=True)
    handler = logging.handlers.RotatingFileHandler(
        log_dir / "agent.log", maxBytes=5_000_000, backupCount=5
    )
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    handler.setFormatter(fmt)
    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(fmt)
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(handler)
    root.addHandler(stream)


_running = True


def _handle_sigterm(signum, frame):
    global _running
    logging.info(f"Signal {signum} received — shutting down cleanly.")
    _running = False


def main() -> None:
    setup_logging()
    log = logging.getLogger("runner")

    signal.signal(signal.SIGINT, _handle_sigterm)
    signal.signal(signal.SIGTERM, _handle_sigterm)

    broker = Broker()
    strat = MaRsiStrategy()

    log.info(
        f"Starting agent | symbol={CONFIG.SYMBOL} tf={CONFIG.TIMEFRAME} "
        f"live={CONFIG.LIVE_TRADING} poll={CONFIG.POLL_INTERVAL_SECONDS}s"
    )

    halted = False

    while _running:
        try:
            df = broker.fetch_ohlcv(limit=max(CONFIG.SLOW_MA * 3, 200))
            last_price = broker.fetch_price()

            if broker.update_peak_and_check_drawdown(last_price):
                if not halted:
                    log.error("Halting new entries. Closing open position if any.")
                    broker.market_sell_all(last_price)
                    halted = True
                time.sleep(CONFIG.POLL_INTERVAL_SECONDS)
                continue

            pos = broker.get_position()
            in_pos = pos.size > 0
            sig = strat.decide(df, in_pos, pos.stop_loss, pos.take_profit, last_price)
            log.info(f"price={last_price:.2f} signal={sig.action} reason={sig.reason}")

            if sig.action == "buy" and not in_pos and not halted:
                equity = broker.get_equity(last_price)
                quote_amount = equity * CONFIG.POSITION_SIZE_PCT
                broker.market_buy(quote_amount, last_price)
            elif sig.action == "sell" and in_pos:
                broker.market_sell_all(last_price)

            equity = broker.get_equity(last_price)
            log.info(f"equity={equity:.2f} peak={broker.paper.peak_equity:.2f}")

        except Exception as e:
            # Never let a transient error kill the loop. Log and keep polling.
            logging.exception(f"Loop error: {e}")

        time.sleep(CONFIG.POLL_INTERVAL_SECONDS)

    log.info("Agent stopped.")


if __name__ == "__main__":
    main()
