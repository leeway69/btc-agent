"""
Simple vectorized backtester. Run BEFORE live trading.

Usage:
    python -m bot.backtest

Fetches historical OHLCV from the configured exchange and simulates the same
strategy the live agent uses. Output tells you whether the strategy has made
money historically — necessary but not sufficient evidence it will make money
going forward.
"""
from __future__ import annotations
import logging
from dataclasses import dataclass

import ccxt
import pandas as pd

from bot import indicators
from config.settings import CONFIG

log = logging.getLogger(__name__)


@dataclass
class Trade:
    entry_ts: pd.Timestamp
    entry_price: float
    exit_ts: pd.Timestamp
    exit_price: float
    reason: str

    @property
    def return_pct(self) -> float:
        return (self.exit_price / self.entry_price) - 1


def fetch_history(limit: int = 1000) -> pd.DataFrame:
    ex = getattr(ccxt, CONFIG.EXCHANGE_ID)({"enableRateLimit": True})
    raw = ex.fetch_ohlcv(CONFIG.SYMBOL, timeframe=CONFIG.TIMEFRAME, limit=limit)
    df = pd.DataFrame(raw, columns=["ts", "open", "high", "low", "close", "volume"])
    df["ts"] = pd.to_datetime(df["ts"], unit="ms")
    return df


def run_backtest(df: pd.DataFrame) -> list[Trade]:
    close = df["close"]
    fast = indicators.sma(close, CONFIG.FAST_MA)
    slow = indicators.sma(close, CONFIG.SLOW_MA)
    rsi = indicators.rsi(close, CONFIG.RSI_PERIOD)

    trades: list[Trade] = []
    in_pos = False
    entry_price = 0.0
    entry_ts = None
    stop = take = 0.0

    for i in range(1, len(df)):
        price = close.iloc[i]
        ts = df["ts"].iloc[i]

        if in_pos:
            if price <= stop:
                trades.append(Trade(entry_ts, entry_price, ts, price, "stop-loss"))
                in_pos = False
                continue
            if price >= take:
                trades.append(Trade(entry_ts, entry_price, ts, price, "take-profit"))
                in_pos = False
                continue
            if fast.iloc[i - 1] >= slow.iloc[i - 1] and fast.iloc[i] < slow.iloc[i]:
                trades.append(Trade(entry_ts, entry_price, ts, price, "ma-cross-down"))
                in_pos = False
                continue
        else:
            crossed_up = fast.iloc[i - 1] <= slow.iloc[i - 1] and fast.iloc[i] > slow.iloc[i]
            # Change 3: require slow MA to be trending up over lookback window
            lookback = CONFIG.TREND_LOOKBACK
            if i >= lookback and not pd.isna(slow.iloc[i - lookback]):
                trending_up = slow.iloc[i] > slow.iloc[i - lookback]
            else:
                trending_up = False
            if crossed_up and rsi.iloc[i] < CONFIG.RSI_OVERBOUGHT and trending_up:
                entry_price = price
                entry_ts = ts
                stop = price * (1 - CONFIG.STOP_LOSS_PCT)
                take = price * (1 + CONFIG.TAKE_PROFIT_PCT)
                in_pos = True

    return trades


def summarize(trades: list[Trade]) -> None:
    if not trades:
        print("No trades generated.")
        return
    returns = pd.Series([t.return_pct for t in trades])
    wins = returns[returns > 0]
    losses = returns[returns <= 0]
    total_return = (1 + returns).prod() - 1
    win_rate = len(wins) / len(returns) if len(returns) else 0

    # Realistic fee estimate: 0.26% taker on Kraken, round-trip = 0.52% per trade
    fee_per_trade = 0.0052
    net_returns = returns - fee_per_trade
    net_total = (1 + net_returns).prod() - 1

    print(f"Trades:          {len(trades)}")
    print(f"Win rate:        {win_rate:.1%}")
    print(f"Avg return/trade:{returns.mean():.2%}")
    print(f"Avg win:         {wins.mean():.2%}" if len(wins) else "Avg win: n/a")
    print(f"Avg loss:        {losses.mean():.2%}" if len(losses) else "Avg loss: n/a")
    print(f"Cumulative P&L:  {total_return:.2%}  (gross, no fees)")
    print(f"After fees:      {net_total:.2%}  (0.26%/side taker fees)")
    print()
    print("Remember: past performance != future results. Slippage, funding rates,")
    print("and look-ahead bias are not modeled here. Validate carefully.")


if __name__ == "__main__":
    df = fetch_history(2000)
    trades = run_backtest(df)
    summarize(trades)
