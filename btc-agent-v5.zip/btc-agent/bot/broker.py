"""
Unified exchange interface. In paper mode, all orders are simulated in memory
at the current market price. In live mode, orders go to the real exchange via CCXT.

Design rule: the strategy never talks to CCXT directly. It goes through this class,
so swapping exchanges or flipping paper/live is a one-line config change.
"""
from __future__ import annotations
import logging
import time
from dataclasses import dataclass, field
from typing import Optional

import ccxt
import pandas as pd

from config.settings import CONFIG

log = logging.getLogger(__name__)


@dataclass
class Position:
    side: Optional[str] = None        # "long" or None (no shorts in this baseline)
    size: float = 0.0                 # BTC amount
    entry_price: float = 0.0
    stop_loss: float = 0.0
    take_profit: float = 0.0


@dataclass
class PaperAccount:
    cash: float
    position: Position = field(default_factory=Position)
    peak_equity: float = 0.0          # for drawdown tracking

    def equity(self, last_price: float) -> float:
        return self.cash + self.position.size * last_price


class Broker:
    """Thin wrapper over CCXT with a paper-trading fallback."""

    def __init__(self) -> None:
        CONFIG.validate()
        exchange_cls = getattr(ccxt, CONFIG.EXCHANGE_ID)
        self.exchange = exchange_cls({
            "apiKey": CONFIG.API_KEY,
            "secret": CONFIG.API_SECRET,
            "enableRateLimit": True,
        })
        self.paper = PaperAccount(cash=CONFIG.PAPER_STARTING_CASH)
        self.paper.peak_equity = self.paper.cash
        self.live = CONFIG.LIVE_TRADING
        if self.live:
            log.warning("LIVE TRADING ENABLED — real orders will be placed.")
        else:
            log.info("Paper trading mode. No real orders will be placed.")

    # ---------- Market data (same in both modes) ----------
    def fetch_ohlcv(self, limit: int = 200) -> pd.DataFrame:
        raw = self.exchange.fetch_ohlcv(CONFIG.SYMBOL, timeframe=CONFIG.TIMEFRAME, limit=limit)
        df = pd.DataFrame(raw, columns=["ts", "open", "high", "low", "close", "volume"])
        df["ts"] = pd.to_datetime(df["ts"], unit="ms")
        return df

    def fetch_price(self) -> float:
        ticker = self.exchange.fetch_ticker(CONFIG.SYMBOL)
        return float(ticker["last"])

    # ---------- Account state ----------
    def get_equity(self, last_price: float) -> float:
        if self.live:
            # For live mode, query real balance. USDT-denominated assumed.
            balances = self.exchange.fetch_balance()
            quote = CONFIG.SYMBOL.split("/")[1]
            base = CONFIG.SYMBOL.split("/")[0]
            cash = balances["total"].get(quote, 0.0)
            coin = balances["total"].get(base, 0.0)
            return float(cash + coin * last_price)
        return self.paper.equity(last_price)

    def get_position(self) -> Position:
        # In this baseline, live mode also tracks position in memory (set on fill).
        # A more robust version would reconcile with exchange-side open orders.
        return self.paper.position

    # ---------- Orders ----------
    def market_buy(self, quote_amount: float, price: float) -> None:
        """Buy `quote_amount` worth of base currency at market."""
        size = quote_amount / price
        if self.live:
            log.info(f"LIVE market buy: {size:.6f} {CONFIG.SYMBOL}")
            self.exchange.create_market_buy_order(CONFIG.SYMBOL, size)
        else:
            log.info(f"PAPER market buy: {size:.6f} @ {price:.2f}")
            self.paper.cash -= quote_amount
        self.paper.position = Position(
            side="long",
            size=size,
            entry_price=price,
            stop_loss=price * (1 - CONFIG.STOP_LOSS_PCT),
            take_profit=price * (1 + CONFIG.TAKE_PROFIT_PCT),
        )

    def market_sell_all(self, price: float) -> None:
        pos = self.paper.position
        if pos.size <= 0:
            return
        if self.live:
            log.info(f"LIVE market sell: {pos.size:.6f} {CONFIG.SYMBOL}")
            self.exchange.create_market_sell_order(CONFIG.SYMBOL, pos.size)
        else:
            log.info(f"PAPER market sell: {pos.size:.6f} @ {price:.2f}")
            self.paper.cash += pos.size * price
        self.paper.position = Position()

    # ---------- Circuit breaker ----------
    def update_peak_and_check_drawdown(self, last_price: float) -> bool:
        """Returns True if drawdown exceeded — caller must halt trading."""
        equity = self.get_equity(last_price)
        if equity > self.paper.peak_equity:
            self.paper.peak_equity = equity
        if self.paper.peak_equity == 0:
            return False
        dd = 1 - (equity / self.paper.peak_equity)
        if dd >= CONFIG.MAX_DRAWDOWN_PCT:
            log.error(f"CIRCUIT BREAKER tripped. Drawdown = {dd:.2%}")
            return True
        return False
