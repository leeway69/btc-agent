"""
Baseline strategy: MA crossover filtered by RSI.

Entry (long):
  - Fast MA crosses above Slow MA
  - RSI is NOT overbought (avoid buying into a blow-off top)

Exit:
  - Fast MA crosses below Slow MA, OR
  - Stop-loss hit, OR
  - Take-profit hit

This is intentionally simple. It is a scaffold, not an edge. Treat it as the
"hello world" of quant strategies and replace the logic once you've backtested
something that actually works on your symbol and timeframe.
"""
from __future__ import annotations
import logging
from dataclasses import dataclass

import pandas as pd

from bot import indicators
from config.settings import CONFIG

log = logging.getLogger(__name__)


@dataclass
class Signal:
    action: str          # "buy", "sell", "hold"
    reason: str


class MaRsiStrategy:
    def __init__(self) -> None:
        self.fast = CONFIG.FAST_MA
        self.slow = CONFIG.SLOW_MA
        self.rsi_period = CONFIG.RSI_PERIOD

    def decide(self, df: pd.DataFrame, in_position: bool,
               stop_loss: float, take_profit: float, last_price: float) -> Signal:
        # Risk management first — it must work even if indicators are undefined
        # (e.g. flat price series → RSI is NaN).
        if in_position:
            if last_price <= stop_loss:
                return Signal("sell", f"stop-loss hit at {last_price:.2f}")
            if last_price >= take_profit:
                return Signal("sell", f"take-profit hit at {last_price:.2f}")

        if len(df) < self.slow + 2:
            return Signal("hold", "not enough candles yet")

        close = df["close"]
        fast_ma = indicators.sma(close, self.fast)
        slow_ma = indicators.sma(close, self.slow)
        rsi = indicators.rsi(close, self.rsi_period)

        crossed_up = indicators.crossed_above(fast_ma, slow_ma)
        crossed_dn = indicators.crossed_below(fast_ma, slow_ma)

        if in_position:
            if crossed_dn:
                return Signal("sell", "fast MA crossed below slow MA")
            return Signal("hold", "holding long")

        # Entry side — need a valid RSI reading
        last_rsi_raw = rsi.iloc[-1]
        if pd.isna(last_rsi_raw):
            return Signal("hold", "RSI not yet defined")
        last_rsi = float(last_rsi_raw)

        # Change 3: require slow MA itself to be trending up.
        # This stops us from buying counter-trend pops during a downtrend.
        lookback = CONFIG.TREND_LOOKBACK
        if len(slow_ma) > lookback and not pd.isna(slow_ma.iloc[-lookback - 1]):
            slow_now = float(slow_ma.iloc[-1])
            slow_then = float(slow_ma.iloc[-lookback - 1])
            trending_up = slow_now > slow_then
        else:
            trending_up = False

        if crossed_up and last_rsi < CONFIG.RSI_OVERBOUGHT and trending_up:
            return Signal("buy", f"MA crossover w/ RSI={last_rsi:.1f}, slow MA rising")
        if crossed_up and not trending_up:
            return Signal("hold", "MA crossed but slow MA not trending up")
        if crossed_up:
            return Signal("hold", f"MA crossed but RSI overbought ({last_rsi:.1f})")
        return Signal("hold", "no signal")
