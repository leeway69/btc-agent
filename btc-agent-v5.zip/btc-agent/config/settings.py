"""
Central configuration. Change parameters here, not in the strategy code.
Secrets come from .env — never hardcode them.
"""
import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


@dataclass
class Config:
    # ---- Exchange ----
    EXCHANGE_ID: str = os.getenv("EXCHANGE_ID", "kraken")  # any ccxt id
    API_KEY: str = os.getenv("EXCHANGE_API_KEY", "")
    API_SECRET: str = os.getenv("EXCHANGE_API_SECRET", "")
    SYMBOL: str = os.getenv("SYMBOL", "BTC/USDT")
    TIMEFRAME: str = os.getenv("TIMEFRAME", "1h")

    # ---- Trading mode ----
    # PAPER = no real orders, simulate fills at current price.
    # LIVE  = real orders. Requires explicit env var LIVE_TRADING=true.
    LIVE_TRADING: bool = os.getenv("LIVE_TRADING", "false").lower() == "true"

    # ---- Strategy params (MA + RSI filter) ----
    # Change 2: longer MAs to filter whipsaws on hourly BTC
    FAST_MA: int = int(os.getenv("FAST_MA", 50))
    SLOW_MA: int = int(os.getenv("SLOW_MA", 200))
    RSI_PERIOD: int = int(os.getenv("RSI_PERIOD", 14))
    RSI_OVERBOUGHT: float = float(os.getenv("RSI_OVERBOUGHT", 70))
    RSI_OVERSOLD: float = float(os.getenv("RSI_OVERSOLD", 30))
    # Change 3: require slow MA itself to be trending up before buying
    TREND_LOOKBACK: int = int(os.getenv("TREND_LOOKBACK", 7))

    # ---- Risk management ----
    # Change 1: tighter stop, wider target → better reward:risk ratio (3:1)
    POSITION_SIZE_PCT: float = float(os.getenv("POSITION_SIZE_PCT", 0.10))   # 10% of equity per trade
    STOP_LOSS_PCT: float = float(os.getenv("STOP_LOSS_PCT", 0.015))          # 1.5%
    TAKE_PROFIT_PCT: float = float(os.getenv("TAKE_PROFIT_PCT", 0.045))      # 4.5% (3:1 R:R)
    MAX_DRAWDOWN_PCT: float = float(os.getenv("MAX_DRAWDOWN_PCT", 0.05))     # circuit breaker at 5%

    # ---- Loop ----
    POLL_INTERVAL_SECONDS: int = int(os.getenv("POLL_INTERVAL_SECONDS", 300))  # 5 min

    # ---- Paper trading starting balance ----
    PAPER_STARTING_CASH: float = float(os.getenv("PAPER_STARTING_CASH", 10000))

    def validate(self) -> None:
        if self.LIVE_TRADING and (not self.API_KEY or not self.API_SECRET):
            raise ValueError("LIVE_TRADING=true but API credentials are missing.")
        if self.FAST_MA >= self.SLOW_MA:
            raise ValueError("FAST_MA must be less than SLOW_MA.")
        if not (0 < self.POSITION_SIZE_PCT <= 1):
            raise ValueError("POSITION_SIZE_PCT must be between 0 and 1.")


CONFIG = Config()
