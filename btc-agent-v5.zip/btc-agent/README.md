# BTC Trading Agent

A paper-first Bitcoin trading scaffold. Uses CCXT for exchange connectivity, a moving-average crossover filtered by RSI for signals, and hard risk controls (stop-loss, take-profit, drawdown circuit breaker).

## Read this first

- This is a **scaffold**, not a profitable strategy. MA crossovers on BTC are one of the most picked-over signals in crypto. Do not expect to print money out of the box.
- **Default mode is paper trading.** Live trading requires you to explicitly set `LIVE_TRADING=true` in `.env` and have valid API keys.
- Most retail trading bots lose money over time. Budget only what you can afford to lose, and paper-trade for at least a month before going live.
- Crypto trading is legally restricted in some jurisdictions. Know your local rules.

## Setup

```bash
cd btc-agent
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env              # then edit with your keys and params
```

When creating exchange API keys:
- Enable **trade** permission only.
- **Disable withdrawals.**
- Enable IP allowlisting if your exchange supports it.

## Run

```bash
# 1. Backtest on historical data
python -m bot.backtest

# 2. Run tests
pytest tests/

# 3. Paper trade (default)
python -m bot.runner

# 4. Live trade — only after the above look good
# Set LIVE_TRADING=true in .env, then:
python -m bot.runner
```

## Running 24/7

A cron job restarts the process periodically, which is wrong for a bot that needs to hold state. Use a supervisor instead:

**systemd** (Linux server):
```ini
# /etc/systemd/system/btc-agent.service
[Unit]
Description=BTC Trading Agent
After=network.target

[Service]
WorkingDirectory=/path/to/btc-agent
ExecStart=/path/to/btc-agent/.venv/bin/python -m bot.runner
Restart=on-failure
RestartSec=10
User=youruser

[Install]
WantedBy=multi-user.target
```

Then `sudo systemctl enable --now btc-agent`.

Or Docker with `restart: unless-stopped`.

## Structure

```
btc-agent/
├── bot/
│   ├── indicators.py    # SMA, RSI, crossover detection
│   ├── strategy.py      # Entry/exit logic
│   ├── broker.py        # Paper and live exchange adapter
│   ├── runner.py        # Main loop
│   └── backtest.py      # Historical simulation
├── config/
│   └── settings.py      # All tunable params (from .env)
├── tests/
│   └── test_strategy.py
├── logs/                # Rotating logs land here
├── .env.example
├── .gitignore
└── requirements.txt
```

## Changing the strategy

Replace `bot/strategy.py`. The `decide()` method returns a `Signal(action, reason)` — anything that honors that interface drops in. Run `pytest` and `backtest.py` before deploying.

## What's missing (and intentionally so)

- **Order reconciliation** with the exchange in live mode is basic. Production would sync position state with the exchange on every tick.
- **No multi-asset support.** One symbol per process. Run multiple processes for multiple symbols.
- **No ML or LLM-in-the-loop decision making.** If you want an LLM to make trading calls, wire it in via MCP as a separate advisor — not the primary decision maker.
- **No tax/reporting**. You are responsible for records.
