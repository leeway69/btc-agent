"""
Tests. Run with:  pytest tests/
Minimal but catches the stuff that quietly breaks trading bots:
  - off-by-one in crossover detection
  - RSI on flat series
  - strategy obeying stop-loss over signal
"""
import pandas as pd
import pytest

from bot import indicators
from bot.strategy import MaRsiStrategy
from config.settings import CONFIG


def test_sma_basic():
    s = pd.Series([1, 2, 3, 4, 5])
    out = indicators.sma(s, 3)
    assert out.iloc[-1] == pytest.approx(4.0)
    assert pd.isna(out.iloc[0])


def test_rsi_on_flat_series_is_nan_or_neutral():
    s = pd.Series([100.0] * 30)
    out = indicators.rsi(s, 14)
    # All gains and losses are zero → rsi undefined; we expect NaN.
    assert pd.isna(out.iloc[-1]) or out.iloc[-1] == 50 or out.iloc[-1] == 0


def test_crossed_above_detects_single_bar_cross():
    fast = pd.Series([1, 2, 3])
    slow = pd.Series([2, 2, 2])
    assert indicators.crossed_above(fast, slow) is True


def test_crossed_above_false_when_already_above():
    fast = pd.Series([3, 4, 5])
    slow = pd.Series([1, 1, 1])
    assert indicators.crossed_above(fast, slow) is False


def test_strategy_exits_on_stop_loss_even_if_no_signal():
    strat = MaRsiStrategy()
    # Build a df with enough bars but no crossover.
    prices = [100 + i * 0.01 for i in range(CONFIG.SLOW_MA + 5)]
    df = pd.DataFrame({"close": prices})
    sig = strat.decide(df, in_position=True, stop_loss=200, take_profit=500,
                       last_price=150)  # last_price < stop_loss
    assert sig.action == "sell"
    assert "stop-loss" in sig.reason


def test_strategy_holds_when_not_enough_data():
    strat = MaRsiStrategy()
    df = pd.DataFrame({"close": [100, 101, 102]})
    sig = strat.decide(df, in_position=False, stop_loss=0, take_profit=0, last_price=102)
    assert sig.action == "hold"
